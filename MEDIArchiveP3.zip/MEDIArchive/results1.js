function clickedBeforeTime()
{
  window.location.href = "results2.html";
}
