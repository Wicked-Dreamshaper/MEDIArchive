function loginButton()
{
	window.location.href = "loginpage.html";
}
