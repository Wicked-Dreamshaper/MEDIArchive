//aboutmediarchive.js

function loginButton()
{
	window.location.href = "loginpage.html";
}