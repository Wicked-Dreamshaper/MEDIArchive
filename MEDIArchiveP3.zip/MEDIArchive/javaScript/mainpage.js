//mainpage.js


//on mouseover events for media
function showinfolbft()
{
	document.getElementById("lbft").style.display = "block";
	document.getElementById("aiw").style.display = "none";
}

function showinfoaiw()
{
	document.getElementById("aiw").style.display = "block";
	document.getElementById("lbft").style.display = "none";
}
