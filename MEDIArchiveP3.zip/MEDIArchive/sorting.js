function mainpage()
{
	window.location.href = "mainPage2.html";
}
